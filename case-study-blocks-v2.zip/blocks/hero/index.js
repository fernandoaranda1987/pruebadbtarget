import { registerBlockType } from '@wordpress/blocks';
import { RichText, useBlockProps } from '@wordpress/block-editor';

registerBlockType('cs/hero', {
  edit: ({ attributes, setAttributes }) => {
    const { title, subtitle } = attributes;
    const blockProps = useBlockProps({ className: 'cs-hero' });
    return (
      <section {...blockProps}>
        <div className="cs-hero__content">
          <RichText
            tagName="h1"
            className="cs-hero__title"
            value={title}
            onChange={(v) => setAttributes({ title: v })}
            placeholder="Escribe el título..."
          />
          <RichText
            tagName="p"
            className="cs-hero__subtitle"
            value={subtitle}
            onChange={(v) => setAttributes({ subtitle: v })}
            placeholder="Escribe el subtítulo..."
          />
        </div>
      </section>
    );
  },
  save: ({ attributes }) => {
    const { title, subtitle } = attributes;
    const blockProps = useBlockProps.save({ className: 'cs-hero' });
    return (
      <section {...blockProps}>
        <div className="cs-hero__content">
          <RichText.Content tagName="h1" className="cs-hero__title" value={title} />
          <RichText.Content tagName="p" className="cs-hero__subtitle" value={subtitle} />
        </div>
      </section>
    );
  }
});
