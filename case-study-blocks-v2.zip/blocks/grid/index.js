import { registerBlockType } from '@wordpress/blocks';
import { useBlockProps } from '@wordpress/block-editor';

registerBlockType('cs/case-studies-grid', {
  edit: () => {
    const blockProps = useBlockProps({ className: 'cs-grid-placeholder' });
    return (
      <div {...blockProps}>
        <p>📦 Case Studies Grid (los ítems se mostrarán en el frontend)</p>
      </div>
    );
  },
  save: () => null // se renderiza en PHP
});
