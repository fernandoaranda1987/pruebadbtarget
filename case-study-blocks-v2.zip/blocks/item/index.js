import { registerBlockType } from '@wordpress/blocks';
import { RichText, useBlockProps } from '@wordpress/block-editor';

registerBlockType('cs/case-study-item', {
  edit: ({ attributes, setAttributes }) => {
    const { projectTitle, description } = attributes;
    const blockProps = useBlockProps({ className: 'cs-item' });
    return (
      <article {...blockProps}>
        <RichText
          tagName="h3"
          className="cs-item__title"
          value={projectTitle}
          onChange={(v) => setAttributes({ projectTitle: v })}
          placeholder="Título del proyecto..."
        />
        <RichText
          tagName="p"
          className="cs-item__desc"
          value={description}
          onChange={(v) => setAttributes({ description: v })}
          placeholder="Descripción..."
        />
      </article>
    );
  },
  save: ({ attributes }) => {
    const { projectTitle, description } = attributes;
    const blockProps = useBlockProps.save({ className: 'cs-item' });
    return (
      <article {...blockProps}>
        <RichText.Content tagName="h3" className="cs-item__title" value={projectTitle} />
        <RichText.Content tagName="p" className="cs-item__desc" value={description} />
      </article>
    );
  }
});
